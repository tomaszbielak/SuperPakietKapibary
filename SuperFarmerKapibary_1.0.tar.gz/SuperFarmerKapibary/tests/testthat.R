library(testthat)
library(SuperFarmerKapibary)

test_check("SuperFarmerKapibary")
